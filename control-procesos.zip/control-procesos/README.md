# Sistema de Control de Procesos
## Subgerencia de Liquidaciones y Devoluciones

---

## Arquitectura

```
GitHub Pages (frontend/index.html)
        ↕ fetch API
Railway o Render (backend/app.py)
        ↕ gspread
Google Sheets (tu archivo existente)
```

---

## PASO 1 — Crear cuenta de servicio en Google Cloud

1. Ir a https://console.cloud.google.com
2. Crear un proyecto nuevo (ej: "control-procesos")
3. Activar APIs:
   - **Google Sheets API**
   - **Google Drive API**
4. Ir a **Credenciales → Crear credenciales → Cuenta de servicio**
5. Nombre: `sheets-backend`
6. Descargar el JSON de la cuenta de servicio → guardar como `credentials.json`
7. Copiar el campo `client_email` del JSON (ej: `sheets-backend@tu-proyecto.iam.gserviceaccount.com`)
8. En tu Google Sheet → **Compartir** → pegar el email → rol **Editor**

---

## PASO 2 — Obtener el Spreadsheet ID

Tu URL de Google Sheets:
```
https://docs.google.com/spreadsheets/d/18AJhwt5VNzxZQxhIO6VvZeKQ4RYmO4uv/edit
                                        ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
                                        Este es tu SPREADSHEET_ID
```

---

## PASO 3 — Desplegar backend en Railway (gratis)

1. Crear cuenta en https://railway.app
2. **New Project → Deploy from GitHub repo**
3. Subir la carpeta `backend/` a un repo de GitHub
4. En Railway → **Variables de entorno** agregar:
   ```
   SPREADSHEET_ID = 18AJhwt5VNzxZQxhIO6VvZeKQ4RYmO4uv
   GOOGLE_CREDENTIALS_JSON = <pegar todo el contenido del credentials.json en una línea>
   PORT = 5000
   ```
5. Railway detecta el `Procfile` y despliega automáticamente
6. Copiar la URL pública que te da Railway (ej: `https://control-procesos.up.railway.app`)

> **Alternativa gratuita**: Render.com funciona igual, también detecta el Procfile.

---

## PASO 4 — Configurar el frontend

En `frontend/index.html`, línea ~310, cambiar:
```javascript
const API = "https://<TU-BACKEND>.railway.app";
```
Por tu URL real de Railway:
```javascript
const API = "https://control-procesos.up.railway.app";
```

También en `backend/app.py`, línea ~11, agregar tu dominio de GitHub Pages:
```python
CORS(app, origins=[
    "https://TU_USUARIO.github.io",
    "http://localhost:3000",
    "http://127.0.0.1:5500"
])
```

---

## PASO 5 — Publicar frontend en GitHub Pages

1. Crear repo en GitHub (ej: `control-procesos`)
2. Subir el archivo `frontend/index.html` a la raíz del repo
3. Renombrarlo a `index.html` (ya tiene ese nombre)
4. Ir a **Settings → Pages → Branch: main → / (root)**
5. Tu app quedará en: `https://TU_USUARIO.github.io/control-procesos`

---

## Estructura de archivos

```
control-procesos/
├── frontend/
│   └── index.html          ← GitHub Pages (este archivo)
└── backend/
    ├── app.py              ← API Flask
    ├── requirements.txt    ← Dependencias Python
    ├── Procfile            ← Para Railway/Render
    └── credentials.json    ← ⚠️ NO subir a GitHub (agregar al .gitignore)
```

---

## .gitignore recomendado (en la carpeta backend)

```
credentials.json
__pycache__/
*.pyc
.env
venv/
```

---

## Endpoints disponibles

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| GET | `/api/records/{modulo}` | Leer todos los registros de una hoja |
| POST | `/api/records/{modulo}` | Crear nuevo registro |
| PUT | `/api/records/{modulo}/{fila}` | Actualizar registro existente |
| GET | `/api/metrics` | Métricas consolidadas de todas las hojas |
| GET | `/api/lists` | Listas de opciones (funcionarios, rentas, etc.) |

### Módulos disponibles
- `base-olga` → hoja "Base Olga"
- `correos` → hoja "BASE CORREOS ELECTRONICOS"
- `nexura` → hoja "Base NEXURA"
- `traslados` → hoja "Base Traslados Fiscalización"
- `resoluciones` → hoja "RES"
- `fiscalizacion` → hoja "Base Traslados Fiscalización"
- `tutelas` → hoja "BASE TUTELAS"

---

## Probar localmente antes de desplegar

```bash
# Backend
cd backend
pip install -r requirements.txt
# Poner credentials.json en esta carpeta
export SPREADSHEET_ID="18AJhwt5VNzxZQxhIO6VvZeKQ4RYmO4uv"
python app.py

# Frontend: abrir frontend/index.html en navegador
# Cambiar API a "http://localhost:5000" para pruebas locales
```

---

## Costo estimado

| Servicio | Costo |
|----------|-------|
| GitHub Pages | Gratis |
| Railway (500 horas/mes) | Gratis |
| Google Sheets API | Gratis (hasta 300 req/min) |
| Google Cloud (cuenta de servicio) | Gratis |
| **Total** | **$0** |
